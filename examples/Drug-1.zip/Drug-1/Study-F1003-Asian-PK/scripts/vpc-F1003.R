#######################################################################################################################
# PROGRAM:       vpc.R
# DESCRIPTION:   This script is supplied with Finch Studio and uses the R package 'vpc' 
#                to create VPC plots from output generated with the PsN command 'vpc'.
# AUTHOR:        Sarah Cook
# DATE:          2022-03-16
# VERSION:       R Version 4.0.4
# REQUIREMENTS:  libraries: vpc, ggplot2; directory with PsN VPC results
# NOTES:         This script will identify the most recent VPC results directory with the 
#                PsN default "vpc_dir" prefix and plot results from that directory.
#######################################################################################################################

###### load libraries ######
library(vpc)
library(ggplot2)
library(dplyr)

###### define file names and directories ######
working_dir <- getwd()
vpc_dirs <- file.info(dir(path = working_dir, pattern = "vpc_dir"))
vpc_dir <- rownames(vpc_dirs)[which.max(vpc_dirs$mtime)]
file_name <- paste0(working_dir,"/output/vpc-all", sep = "")
dir.create(file.path(dirname(file_name)))

###### specify variables and labels ######

sim_dv <- "DV"                  # name of dependent variable column in simulated data
sim_idv <- "TIME"               # name of independent variable column in simulated data
obs_dv <- "DV"                  # name of dependent variable column in observed data
obs_idv <- "TIME"               # name of independent variable column in observed data

ylab <- "Dependent Variable"    # y-axis label
xlab <- "Independent Variable"  # x-axis label

###### read in and format data ######

# read in the simulated data from PsN
if(file.exists(paste0(vpc_dir,"/m1.zip"))){
unzip(paste0(vpc_dir,"/m1.zip"),exdir=paste0(vpc_dir))
}
sim <- read.table(paste0(vpc_dir,"/m1/vpc_simulation.1.npctab.dta"), 
                  sep = "", skip = 1, header = TRUE, fill = TRUE, stringsAsFactors = FALSE, na.strings = NA)

sim <- subset(sim, grepl("[0-9]", sim[,1])) # remove extra headers
sim[] <- lapply(sim, as.numeric)

# read in the observed data
obs <- read.table(paste0(vpc_dir,"/m1/vpc_original.npctab.dta"), 
                  sep = "", skip = 1, header = TRUE, fill = TRUE, stringsAsFactors = FALSE, na.strings = NA)

obs <- subset(obs, grepl("[0-9]", obs[,1])) # remove extra headers
obs[] <- lapply(obs, as.numeric)



p1 <- list()
index = 0
for(i in 1){
  index = index+1
  ###### create vpcdb ######
  vpc1 <- vpc::vpc(sim = sim,
                   obs = obs,
                   sim_cols = list(
                     dv = sim_dv,
                     idv = sim_idv
                   ),
                   obs_cols = list(
                     dv = obs_dv,
                     idv = obs_idv
                   ),
                   stratify = NULL,
                   # facet = "rows",
                   # scales = "fixed",
                   # bins = c(),               # specify bin separators for idv manually
                   bins = "fisher",
                   n_bins = "auto",
                   bin_mid = "mean",
                   pred_corr = FALSE,          # perform prediction-correction?
                   pred_corr_lower_bnd = 0,
                   uloq = NULL,
                   lloq = NULL,
                   pi = c(0.05, 0.95),         # prediction interval simulated data to show
                   ci = c(0.025, 0.975),       # confidence intervals to show
                   vpcdb = TRUE)
  
  ###### plot the VPC results ###### 
  plot_vpc <- plot_vpc(vpc1,
                       title = NULL,
                       xlab = xlab,
                       ylab = ylab,
                       log_y = TRUE,
                       # log_y_min = 0.001,
                       show = list(
                         obs_dv = TRUE,        # the observed data
                         obs_ci = TRUE,         # the confidence interval of the observed data
                         obs_median = TRUE,     # the median of the observed data
                         sim_median = FALSE,    # the median of the simulated data
                         sim_median_ci = TRUE,  # the confidence interval around the median of the simulated data
                         pi = FALSE,            # the prediction interval quantiles
                         pi_ci = TRUE,          # the confidence interval around the prediction interval quantiles
                         pi_as_area = FALSE,    # show the PI as area instead of two lines
                         bin_sep = TRUE),       # show the bin separators (as geom_rug)
                       smooth = TRUE, 
                       vpc_theme =  new_vpc_theme(list(
                         obs_color = "#000000",
                         obs_size = 1,
                         obs_median_color = "#000000",
                         obs_median_linetype = "solid",
                         obs_median_size = 0.5,
                         obs_alpha = 0,
                         obs_shape = 1,
                         obs_ci_color = "#000000",
                         obs_ci_linetype = "dashed",
                         obs_ci_size = .5,                       
                         sim_pi_fill = "#0080cf",
                         sim_pi_alpha = 0.35,  
                         sim_pi_color = "#000000",
                         sim_pi_linetype = 'dotted',
                         sim_pi_size = 1,                     
                         sim_median_fill = "grey60",
                         sim_median_alpha = 0.3,  
                         sim_median_color = "#000000",
                         sim_median_linetype = "dashed",
                         sim_median_size = 1,
                         bin_separators_color = "#000000"))) + theme_bw()

  
  p1[[index]] <- plot_vpc
  print(p1[[index]])
  
}



ggsave(paste0(file_name,".png"),p1[[1]], height = 6, width = 10)

# # open created file
# if (file.exists(file_name) ) {
#   switch(Sys.info()['sysname'],
#          "Windows" = shell.exec(file_name),
#          "Darwin" = system(paste ("open ",file_name, sep="")),
#          "Linux" = system(paste("xdg-open ", file_name, sep=""), ignore.stdout=TRUE, ignore.stderr=TRUE, wait=FALSE))
# }
